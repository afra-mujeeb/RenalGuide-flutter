import 'package:flutter/material.dart';
import 'package:renalguide/Caretaker/login.dart';

class Registerstaffscreen extends StatelessWidget {
  const Registerstaffscreen({super.key});

  @override
  Widget build(BuildContext context) {
    final TextEditingController name = TextEditingController();
    final TextEditingController password = TextEditingController();
    final TextEditingController age = TextEditingController();
    final TextEditingController phoneNumber = TextEditingController();
    final TextEditingController sex = TextEditingController();
    final TextEditingController email = TextEditingController();
    final TextEditingController qualification = TextEditingController();
    final TextEditingController experience = TextEditingController();

    final formKey = GlobalKey<FormState>();

    return Scaffold(
      backgroundColor: const Color(0xFFE1F4F3), // Soft mint background

      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(30),
              boxShadow: [
                BoxShadow(
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                  color: Colors.black.withOpacity(0.1),
                ),
              ],
            ),

            child: Form(
              key: formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  
                  const Text(
                    "Create account",
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 5),

                  const Text(
                    "Please enter your details",
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                  ),
                  const SizedBox(height: 25),

                  buildField(
                      controller: name,
                      label: "Your Name",
                      hint: "Enter your name",
                      icon: Icons.person),

                  buildField(
                      controller: email,
                      label: "Your Email",
                      hint: "Enter your email",
                      icon: Icons.email),

                  buildField(
                      controller: password,
                      label: "Password",
                      hint: "Enter your password",
                      icon: Icons.lock,
                      isPassword: true),

                  buildField(
                      controller: age,
                      label: "Age",
                      hint: "Enter your age",
                      icon: Icons.cake,
                      inputType: TextInputType.number),

                  buildField(
                      controller: phoneNumber,
                      label: "Phone Number",
                      hint: "Enter your phone number",
                      icon: Icons.phone,
                      inputType: TextInputType.phone),

                  buildField(
                    controller: sex,
                    label: "Sex",
                    hint: "Enter your gender",
                    icon: Icons.group,
                  ),

                  buildField(
                      controller: qualification,
                      label: "Qualification",
                      hint: "Enter your qualification",
                      icon: Icons.school),

                  buildField(
                      controller: experience,
                      label: "Experience",
                      hint: "Enter experience in years",
                      icon: Icons.work),

                  const SizedBox(height: 25),

                  // --- Register Button ---
                  Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      gradient: const LinearGradient(
                        colors: [
                          Color(0xFF17C3B2),
                          Color(0xFF0AA39D),
                        ],
                      ),
                    ),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      onPressed: () {
                        if (formKey.currentState!.validate()) {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const Loginscreen()),
                          );
                        }
                      },
                      child: const Text(
                        "Register",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  Center(
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const Loginscreen()),
                        );
                      },
                      child: const Text(
                        "Already have an account? Login",
                        style: TextStyle(
                          color: Color(0xFF0AA39D),
                          fontSize: 14,
                        ),
                      ),
                    ),
                  )

                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Reusable TextField Widget
  Widget buildField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    bool isPassword = false,
    TextInputType inputType = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          
          Text(
            label,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),

          const SizedBox(height: 6),

          TextFormField(
            controller: controller,
            obscureText: isPassword,
            keyboardType: inputType,
            validator: (value) {
              if (value == null || value.isEmpty) return "Required";
              return null;
            },
            decoration: InputDecoration(
              hintText: hint,
              filled: true,
              fillColor: const Color(0xFFF5F7F9),
              prefixIcon: Icon(icon, color: Colors.grey),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
