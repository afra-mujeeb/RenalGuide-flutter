import 'package:flutter/material.dart';

class Addpatient extends StatelessWidget {
  const Addpatient({super.key});

  @override
  Widget build(BuildContext context) {
    final TextEditingController Name = TextEditingController();
    final TextEditingController Age = TextEditingController();
    final TextEditingController Sex = TextEditingController();
    final formkey = GlobalKey<FormState>();

    return Scaffold(
      backgroundColor: const Color(0xFFF4F7F9),

      appBar: AppBar(
        title: const Text(
          'Add Patient',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.teal.shade600,
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: formkey,
          child: Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [

                  const Text(
                    "Add New Patient",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w600,
                    ),
                  ),

                  const SizedBox(height: 20),

                  // NAME FIELD
                  TextFormField(
                    controller: Name,
                    validator: (value) =>
                        value == null || value.isEmpty ? "Enter patient name" : null,
                    decoration: inputStyle("Patient Name"),
                  ),

                  const SizedBox(height: 12),

                  // AGE FIELD
                  TextFormField(
                    controller: Age,
                    validator: (value) =>
                        value == null || value.isEmpty ? "Enter patient age" : null,
                    decoration: inputStyle("Age"),
                    keyboardType: TextInputType.number,
                  ),

                  const SizedBox(height: 12),

                  // SEX FIELD
                  TextFormField(
                    controller: Sex,
                    validator: (value) =>
                        value == null || value.isEmpty ? "Enter patient sex" : null,
                    decoration: inputStyle("Sex"),
                  ),

                  const SizedBox(height: 20),

                  // SUBMIT BUTTON
                  SizedBox(
                    width: double.infinity,
                    child: Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [
                            Color(0xFF009688), // teal gradient same as login
                            Color(0xFF00BFA5),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        onPressed: () {
                          if (formkey.currentState!.validate()) {}
                        },
                        child: const Text(
                          "Add Patient",
                          style: TextStyle(
                            fontSize: 17,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),

                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Reusable input style
  InputDecoration inputStyle(String hint) {
    return InputDecoration(
      labelText: hint,
      filled: true,
      fillColor: Colors.grey.shade100,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
    );
  }
}
