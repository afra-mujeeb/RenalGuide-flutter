package com.example.renalguide

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
